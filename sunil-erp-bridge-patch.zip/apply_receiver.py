"""ERP 서버에서 실행. 지원 원본과 다르면 아무 파일도 교체하지 않습니다."""
import ast,hashlib,json,os,shutil,sys,uuid
from pathlib import Path
from datetime import datetime
ROOT=Path(__file__).resolve().parent

def digest(data):return hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()
def main(target=None):
 target=target or input('ERP 프로그램 폴더 경로(manage.py가 있는 폴더): ').strip().strip('"')
 base=Path(target).resolve()
 if not (base/'manage.py').is_file() or not (base/'inventory').is_dir():raise ValueError('manage.py와 inventory가 있는 ERP 폴더를 선택하세요.')
 entries=json.loads((ROOT/'manifest.json').read_text());changes=[]
 for entry in entries:
  name=entry['path'];dest=(base/name).resolve();source=ROOT/'payload'/name
  if base not in dest.parents:raise ValueError('잘못된 파일 경로입니다.')
  content=source.read_bytes()
  if digest(content)!=entry['after']:raise ValueError('패치 파일이 손상됐습니다: '+name)
  if name.endswith('.py'):ast.parse(content.decode('utf-8-sig'))
  current=digest(dest.read_bytes()) if dest.exists() else None
  if current==entry['after']:continue
  if current!=entry['before']:raise ValueError('기존 코드 버전이 다릅니다. 변경 없이 중단합니다: '+name+'\n현재 ERP 소스를 확인한 뒤 맞는 패치가 필요합니다.')
  changes.append((dest,content,dest.read_bytes() if dest.exists() else None))
 if not changes:print('이미 적용된 버전입니다. ERP 서버를 재시작하세요.');return
 backup=base/'receiver-code-backups'/(datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid.uuid4().hex[:8]);backup.mkdir(parents=True)
 written=[]
 try:
  for dest,content,old in changes:
   if old is not None:
    b=backup/dest.relative_to(base);b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(old)
   dest.parent.mkdir(parents=True,exist_ok=True);temp=dest.with_name(dest.name+'.bridge-tmp');temp.write_bytes(content);os.replace(temp,dest);written.append((dest,old))
 except Exception:
  for dest,old in reversed(written):
   if old is None:dest.unlink(missing_ok=True)
   else:dest.write_bytes(old)
  raise
 print('ERP 수신·회신 코드 적용 완료:',len(changes),'개 파일')
 print('기존 코드 백업:',backup)
 print('재고 DB는 변경하지 않았습니다. ERP 서버를 다시 시작하세요.')
if __name__=='__main__':
 try:main(sys.argv[1] if len(sys.argv)>1 else None)
 except Exception as e:print('적용 중단:',e);sys.exit(1)
