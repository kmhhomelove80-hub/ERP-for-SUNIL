@echo off
setlocal
chcp 65001 >nul
set "PYTHONUTF8=1"
cd /d "%~dp0"
py -3 apply_receiver.py
pause
endlocal
