import unittest,tempfile,io,json,base64,gzip,sqlite3
from pathlib import Path
from copy import deepcopy
from openpyxl import Workbook,load_workbook
from app.engine import HEADERS
from app.advanced import parse_shipment_file
from app.shipments import Shipments
from app.bridge import Bridge,project_title
from app.shipment_totals import display_key

class UI7DataTests(unittest.TestCase):
 def records(self):
  w=Workbook();s=w.active;s.append(HEADERS+['공급가액','부가세','합계금액'])
  for i,(q,total,set_) in enumerate([(1,2,'A'),(1,None,'A'),(12,12,'B'),(3,3,'C')],2):s.append(['POR'+str(i),'H','B','자재',q,'CODE',total,set_,'2026-01-01',1,'창고','2026-12-01',q*100,q*10,q*110])
  s.merge_cells('G2:G3');f=io.BytesIO();w.save(f);return parse_shipment_file(f.getvalue(),'기존자료')[0]
 def test_import_totals_and_explicit_merge_groups_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   l=Shipments(Path(d)/'db');records=self.records();l.import_records('import-file','hash','기존자료',records);rows=l.rows();self.assertEqual([r['values'][6] for r in rows],[2,2,12,3]);self.assertEqual(display_key(rows[0]),display_key(rows[1]));self.assertNotEqual(display_key(rows[1]),display_key(rows[2]));self.assertEqual(l.rows(q='POR4')[0]['values'][6],12)
 def test_old_import_without_merge_metadata_does_not_mix_codes(self):
  with tempfile.TemporaryDirectory() as d:
   l=Shipments(Path(d)/'db');records=self.records()
   for r in records:r.pop('import_total_group');r.pop('total_origin')
   l.import_records('import-old','hash','기존자료',records);rows=l.rows();self.assertEqual([r['values'][6] for r in rows],[2,2,12,3]);self.assertNotEqual(display_key(rows[0]),display_key(rows[1]))
 def test_import_edit_only_known_original_group(self):
  with tempfile.TemporaryDirectory() as d:
   l=Shipments(Path(d)/'db');l.import_records('import-edit','hash','기존자료',self.records());rows=l.rows();l.edit([rows[0]['id']],4);self.assertEqual([r['values'][6] for r in l.rows()],[5,5,12,3]);l.undo();self.assertEqual([r['values'][6] for r in l.rows()],[2,2,12,3])
 def test_uniform_set_is_project_not_hull(self):
  rows=self.records()[:2];self.assertEqual(project_title(rows),'A')
 def test_different_or_empty_sets_require_title(self):
  with self.assertRaises(ValueError):project_title(self.records())
  rows=self.records()[:1];rows[0]['values'][7]=''
  with self.assertRaises(ValueError):project_title(rows)
  self.assertEqual(project_title(rows,'담당/구분/일자'),'담당/구분/일자')
 def test_title_control_characters_rejected(self):
  for title in ['a\nb','x'*251,'\x00', '']:
   with self.assertRaises(ValueError):project_title(self.records(),title)
 def test_forward_title_and_reopen_metadata_preserved(self):
  with tempfile.TemporaryDirectory() as d:
   b=Bridge(Path(d)/'db');b.set_url('http://127.0.0.1:8080/picking/new/');rows=self.records()[:1];sent=b.send('project-key-123456','hash',rows,'http://127.0.0.1:8000/');token=sent['url'].split('#sunil_forward=')[1];f=json.loads(gzip.decompress(base64.urlsafe_b64decode(token+'='*((4-len(token)%4)%4))));self.assertEqual(f['project'],'A');self.assertEqual(len(f['rows'][0]['values']),7);self.assertEqual(b.result(sent['id'])['project'],'A')
 def test_reimport_old_file_restores_only_merge_metadata(self):
  with tempfile.TemporaryDirectory() as d:
   l=Shipments(Path(d)/'db');new=self.records();old=deepcopy(new)
   for r in old:r.pop('import_total_group');r.pop('total_origin')
   l.import_records('same-file','hash','기존자료',old);before=l.rows();l.update([before[0]['id']],status='erp_completed',memo='사용자 메모');result=l.import_records('same-file','hash','기존자료',new);self.assertFalse(result['inserted']);self.assertEqual(result['restored_groups'],4);after=l.rows();self.assertEqual(len(after),4);self.assertEqual(after[0]['status'],'erp_completed');self.assertEqual(after[0]['memo'],'사용자 메모');self.assertEqual([r['values'][6] for r in after],[2,2,12,3]);self.assertEqual(after[0]['import_total_group'],after[1]['import_total_group'])
 def test_import_delete_updates_only_original_group_and_undo(self):
  with tempfile.TemporaryDirectory() as d:
   l=Shipments(Path(d)/'db');l.import_records('delete-file','hash','기존자료',self.records());before=l.rows();l.edit([before[0]['id']],delete=True);self.assertEqual([r['values'][6] for r in l.rows()],[1,12,3]);l.undo();self.assertEqual([r['values'][6] for r in l.rows()],[2,2,12,3])
