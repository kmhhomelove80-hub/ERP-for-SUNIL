import tempfile,unittest,io,base64,gzip,json
from pathlib import Path
from unittest.mock import patch
from fastapi.testclient import TestClient
from openpyxl import load_workbook
from app.store import Store
from app.service import initialize
from app.bridge import Bridge
from app import main
from test_workspace import fixture

class FinalAPITests(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.store=Store(Path(self.tmp.name)/'test.db');book=fixture();r=book['ERP'][1];r[19+20]=10;r[19+27:19+30]=[1000000,100000,1100000];self.store.commit(initialize(book),0)
  self.mock=patch.object(main,'STORE',self.store);self.mock.start();self.addCleanup(self.mock.stop);self.client=TestClient(main.app)
  self.id=next(r['id'] for r in self.client.get('/api/orders/all').json()['rows'] if r['yard']=='HMD')
  self.req={'revision':1,'order_ids':[self.id],'quantity_overrides':{'0':7},'set_notes':{'0':'담당/구분/일자'}}
 def test_preview_download_confirm_use_same_edited_quantity_and_price(self):
  r=self.client.post('/api/extract',json=self.req);self.assertEqual(r.status_code,200);v=r.json()['rows'][0]['values'];self.assertEqual(v[4],7);self.assertEqual(v[6],7);self.assertEqual(v[12:],[700000,70000,770000])
  d=self.client.post('/api/extract/download',json=self.req);self.assertEqual(d.status_code,200);w=load_workbook(io.BytesIO(d.content));s=w['추출'];self.assertEqual(s['F2'].value,7);self.assertEqual(s['N2'].value,700000);self.assertEqual(s['F2'].alignment.horizontal,'right');self.assertEqual(s['D2'].alignment.horizontal,'center');w.close()
  c=self.client.post('/api/shipments/confirm',json={**self.req,'request_key':'confirm-request-123456'});self.assertEqual(c.status_code,200);rows=self.client.get('/api/shipments').json()['rows'];self.assertEqual(rows[0]['values'],v)
  original=next(r for r in self.client.get('/api/orders/all').json()['rows'] if r['id']==self.id);self.assertEqual(original['values'][4],2)
 def test_bridge_send_carries_override_and_deleted_endpoints_guarded(self):
  Bridge(self.store.path).set_url('http://127.0.0.1:8080/picking/new/')
  sent=self.client.post('/api/bridge/send',json={**self.req,'request_key':'send-request-123456','reply_url':'http://127.0.0.1:8000/'});self.assertEqual(sent.status_code,200);s=sent.json();token=s['url'].split('#sunil_forward=')[1];f=json.loads(gzip.decompress(base64.urlsafe_b64decode(token+'='*((4-len(token)%4)%4))));self.assertEqual(f['rows'][0]['values'][4:7],[7,'CODE',7])
  self.assertEqual(self.client.post('/api/bridge/delete',json={'ids':[s['id']]}).status_code,200)
  self.assertEqual(self.client.post('/api/bridge/reopen/'+s['id']).status_code,400)
  self.assertEqual(self.client.post('/api/bridge/set-notes',json={'id':s['id'],'notes':{'0':'재입력'}}).status_code,400)
  self.assertEqual(self.client.get('/api/bridge').json()['transfers'],[])
 def test_migration_preserves_confirmed_ledger_and_rebuilds_original_quantity(self):
  self.client.post('/api/shipments/confirm',json={**self.req,'request_key':'migration-confirm-123456'});before=self.client.get('/api/shipments').json()['rows']
  state=self.store.read();state={**state,'schema_version':4};self.store.commit(state,1);self.client.get('/api/state');self.assertEqual(self.store.read()['schema_version'],6);self.assertEqual(self.client.get('/api/shipments').json()['rows'],before)
 def test_invalid_edit_does_not_write_source(self):
  for overrides in [{'0':-1},{'99':1}]:
   r=self.client.post('/api/extract',json={**self.req,'quantity_overrides':overrides});self.assertEqual(r.status_code,400)
  self.assertEqual(self.store.read()['revision'],1)
 def test_result_filter_limits_download_and_confirm(self):
  r=self.client.post('/api/extract',json={**self.req,'result_indices':[0]});self.assertEqual(r.status_code,200)
  bad=self.client.post('/api/extract',json={**self.req,'result_indices':[5]});self.assertEqual(bad.status_code,400)
 def test_shipment_filtered_download_and_close_preview(self):
  from test_ui7_data import UI7DataTests
  from app.shipments import Shipments
  ledger=Shipments(self.store.path);ledger.import_records('import-for-export','hash','기존자료',UI7DataTests().records());rows=ledger.rows();ledger.update([r['id'] for r in rows],status='erp_completed')
  d=self.client.post('/api/shipments/ids-download',json={'ids':[rows[2]['id']]});self.assertEqual(d.status_code,200);w=load_workbook(io.BytesIO(d.content));self.assertEqual(w['출고내역'].max_row,2);self.assertEqual(w['출고내역']['J2'].value,12);w.close()
  p=self.client.post('/api/close/preview',json={'week':'2026-W45','ids':[rows[2]['id']]});self.assertEqual(p.status_code,200);self.assertEqual(p.json()['count'],1);self.assertEqual(p.json()['quantity'],12)
