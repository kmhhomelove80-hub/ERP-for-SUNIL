"""추출 SET 입력은 원본 REF와 분리하여 확정 스냅샷에 저장."""
def apply_notes(rows,notes):
 if len(notes)>len(rows):raise ValueError('SET 입력 행 수가 결과와 다릅니다.')
 for i,value in notes.items():
  if not 0<=i<len(rows) or not isinstance(value,str) or len(value)>500 or any(c in value for c in '\r\n\t\x00'):raise ValueError('SET는 행별 500자 이내 한 줄로 입력하세요.')
 for i,value in notes.items():rows[i]['values'][7]=value.strip()
