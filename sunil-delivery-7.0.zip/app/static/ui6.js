/* 숫자 셀 직접 편집. 추출 원본은 유지하며 서버에서 다시 계산합니다. */
function attachQuantityEditors(){
 const table=$('extractTable').querySelector('table');if(!table)return;
 const headers=[...table.querySelectorAll('thead th')].map(widthName),column=headers.indexOf('수량');if(column<0)return;
 const rows=cellGrid(table);
 rows.forEach((cells,visibleIndex)=>{const i=Number(table.querySelectorAll('tbody tr')[visibleIndex].dataset.sourceIndex??visibleIndex);const td=cells[column];if(!td)return;
  td.title=activeTransfer?'ERP로 전송한 수량은 변경할 수 없습니다. 새로 추출한 자료에서 수정하세요.':shipmentConfirmed?'출고 확정된 추출입니다.':'더블클릭하여 이번 추출 수량 수정';
  td.classList.add('quantity-cell');td.ondblclick=()=>{
   if(busy||!lastExtract||activeTransfer||shipmentConfirmed||td.querySelector('input'))return;
   const old=window.extractionPreview?.rows[i]?.values[4]??0,input=el('input');input.type='number';input.min='0';input.step='any';input.className='quantity-editor';input.setAttribute('aria-label',`${i+1}행 추출 수량`);input.value=old;td.replaceChildren(input);input.focus();input.select();let done=false;
   const restore=()=>{td.replaceChildren(el('span',format(old)));};
   function commit(){if(done)return;done=true;const q=Number(input.value);if(!input.value.trim()||!Number.isFinite(q)||q<0){restore();notice('수량은 0 이상의 유한한 숫자여야 합니다.',true);return}if(q===old){restore();return}
    const req={...lastExtract,quantity_overrides:{...lastExtract.quantity_overrides,[i]:q}};
    work(async()=>{try{await displayExtract(req);notice('이번 추출 수량·합계·금액을 재계산했습니다. 수주현황 원본은 유지됩니다.');}catch(e){restore();throw e}});
   }
   input.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();commit()}else if(e.key==='Escape'){e.preventDefault();done=true;restore()}};input.onblur=commit;
  };
 });
 const preview=window.extractionPreview;
 if(!activeTransfer&&preview?.rows)rows.forEach((cells,visibleIndex)=>{const i=Number(table.querySelectorAll('tbody tr')[visibleIndex].dataset.sourceIndex??visibleIndex);const reason=preview.rows[i]?.pricing?.reason;for(const name of ['공급가액','부가세','합계금액']){const td=cells[headers.indexOf(name)];if(td){td.title=reason||'ERP 단가 × 수량 (원수주수량 기준)';if(reason)td.classList.add('price-review')}}});
}
const ui6Display=displayExtract;displayExtract=async function(req){await ui6Display(req);attachQuantityEditors();};
const ui6Transfer=showTransfer;showTransfer=async function(id){await ui6Transfer(id);attachQuantityEditors();};
/* 병합된 합계 셀과 체크박스를 고려해 실제 헤더 기준으로 정렬합니다. */
const numericHeaders=new Set(['수량','요청 수량','배정 수량','부족 수량','합계','합계수량','공급가액','공급금액','부가세','합계금액','출고잔량','행 수']);
let alignScheduled=false;
function alignTables(){for(const table of document.querySelectorAll('table')){const headers=[...table.querySelectorAll('thead th')].map(widthName);const grid=cellGrid(table);for(const row of grid)for(let i=0;i<row.length;i++)if(row[i])row[i].classList.toggle('numeric-cell',numericHeaders.has(headers[i]));}}
new MutationObserver(()=>{if(!alignScheduled){alignScheduled=true;requestAnimationFrame(()=>{alignScheduled=false;alignTables()})}}).observe(document.body,{childList:true,subtree:true});
alignTables();
