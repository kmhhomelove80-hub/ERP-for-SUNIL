"""기존자료의 원본 합계와 신규 확정 묶음의 합계를 구분합니다."""
from .engine import product_key

def imported(rec):return 'import_status' in rec or rec.get('total_origin')=='excel'
def total_key(rec):
 if imported(rec):return (rec['batch_id'],'excel',rec.get('import_total_group') or 'row:'+str(rec.get('id')))
 return (rec['batch_id'],rec['yard'],product_key(rec['values']))
def display_key(rec):
 return (*total_key(rec),rec['values'][6],rec['status'])
def refresh_totals(records):
 sums={};edited=set()
 for rec in records:
  key=total_key(rec);sums[key]=sums.get(key,0)+(rec['values'][4] or 0)
  if rec.get('import_total_edited'):edited.add(key)
 for rec in records:
  key=total_key(rec)
  if not imported(rec) or key in edited:rec['values'][6]=sums[key]
 return records

def merge_totals(sheet,records,column=10):
 start=2
 for i,r in enumerate(records):
  if i==len(records)-1 or display_key(r)!=display_key(records[i+1]):
   if i+2>start:sheet.merge_cells(start_row=start,start_column=column,end_row=i+2,end_column=column)
   start=i+3
