"""수주 원수량 기준 단가. 출고잔량을 단가의 분모로 사용하지 않습니다."""
from decimal import Decimal,ROUND_HALF_UP,ROUND_FLOOR
from collections import defaultdict
from .engine import text,product_key
MONEY_HEADERS=['공급가액','부가세','합계금액']
def dec(v):return Decimal(str(v))
def rounded(v):return int(v.quantize(Decimal('1'),rounding=ROUND_HALF_UP))
def price_for(order,candidates):
 v=order['values'];code=text(v[5]).casefold()
 if not code:return {'reason':'ERP CODE 없음'}
 found=[(i,e) for i,e in candidates if text(e[9]).casefold()==code and text(e[2])==text(v[1])]
 # 시트는 RAW 출처이며 ERP 거래처 분류와 다를 수 있습니다.
 # 원본 변환에서 조회한 수주 참조가 있으면 함께 대조합니다.
 if text(v[8]):found=[(i,e) for i,e in found if text(e[10])==text(v[8])]
 if text(v[9]):found=[(i,e) for i,e in found if text(e[11])==text(v[9])]
 if order['yard']=='중소':found=[(i,e) for i,e in found if e[1]=='중소']
 if not found:return {'reason':'POR·호선·품목·수주 참조 매칭 실패'}
 if len({text(e[0]) for _,e in found})>1:return {'reason':'동일 키에 여러 거래처 매칭'}
 prices=[]
 for i,e in found:
  # 새 변환 자료의 19번째 값은 원수주수량입니다. 이전 잔량으로 대체하지 않습니다.
  qty=e[18] if len(e)>18 else None;explicit=e[19] if len(e)>19 else None
  if qty is None or dec(qty)<=0:return {'reason':'ERP 원수주수량 없음 또는 0'}
  if explicit is not None:unit=dec(explicit)
  elif e[13] is not None:unit=dec(e[13])/dec(qty)
  else:return {'reason':'ERP 단가·공급가액 없음'}
  if unit<0:return {'reason':'음수 단가 확인 필요'}
  vat=e[14]
  if vat is None and e[13] is not None and e[15] is not None:vat=dec(e[15])-dec(e[13])
  if vat is None:rate=None
  elif dec(vat)==0:rate=Decimal(0)
  elif e[13] is None or dec(e[13])<=0:return {'reason':'ERP 과세 기준 확인 필요'}
  else:rate=dec(vat)/dec(e[13])
  if rate is not None and rate<0:return {'reason':'음수 부가세 확인 필요'}
  prices.append((unit,rate))
 if len(set(prices))!=1:return {'reason':'동일 매칭 키에 서로 다른 단가·과세 기준'}
 unit,rate=prices[0]
 return {'unit':str(unit),'tax_rate':str(rate) if rate is not None else None,'basis_quantity':sum(e[18] for _,e in found),'basis':'ERP 수주수량','group':[order['yard'],text(v[0]),text(v[1]),code,text(found[0][1][0])],'reason':'' if rate is not None else '부가세 기준 확인 필요'}

def distribute(exact):
 """행별 합산이 그룹 합계와 같도록 원 단위 차이를 큰 소수부부터 배분."""
 floors=[int(x.to_integral_value(rounding=ROUND_FLOOR)) for x in exact]
 gap=rounded(sum(exact,Decimal(0)))-sum(floors)
 for i in sorted(range(len(exact)),key=lambda i:(-(exact[i]-floors[i]),i))[:gap]:floors[i]+=1
 return floors

def recalculate(records):
 groups=defaultdict(list)
 for rec in records:
  v=rec['values'];v.extend([None]*max(0,15-len(v)));p=rec.get('pricing',{})
  v[12:15]=[None,None,None]
  if 'unit' not in p:continue
  key=tuple(p.get('group',[rec['yard'],text(v[0]),text(v[1]),text(v[5])]))+(p['unit'],p.get('tax_rate'))
  groups[key].append(rec)
 for rows in groups.values():
  p=rows[0]['pricing'];exact=[dec(r['values'][4] or 0)*dec(p['unit']) for r in rows];supply=distribute(exact)
  tax=distribute([x*dec(p['tax_rate']) for x in exact]) if p.get('tax_rate') is not None else [None]*len(rows)
  for r,a,b in zip(rows,supply,tax):r['values'][12:15]=[a,b,a+b if b is not None else None]
 return records

def attach_pricing(records,erp):
 by_por=defaultdict(list)
 for i,e in enumerate(erp):by_por[text(e[8])].append((i,e))
 for rec in records:
  rec['pricing']=price_for(rec,by_por[text(rec['values'][0])]);rec['unmatched']=bool(rec['pricing'].get('reason'))
 return recalculate(records)

def totals(records):
 sums=defaultdict(float)
 for r in records:sums[(r['yard'],product_key(r['values']))]+=r['values'][4] or 0
 for r in records:
  n=sums[(r['yard'],product_key(r['values']))];r['values'][6]=int(n) if n.is_integer() else n

def apply_quantities(result,overrides):
 from .order_edits import quantity
 rows=result['rows']
 for key,value in overrides.items():
  if type(key) is not int or not 0<=key<len(rows):raise ValueError('수량을 수정할 추출 행이 없습니다. 다시 추출하세요.')
  rows[key]['values'][4]=quantity(value)
 totals(rows);recalculate(rows);result['stats']['quantity']=sum(r['values'][4] or 0 for r in rows)
 return result
