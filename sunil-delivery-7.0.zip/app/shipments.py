"""확정 당시 자료를 보관하는 누적 출고 원장. RAW 전체 교체와 독립."""
import json
import sqlite3
import uuid
from .engine import product_key
from datetime import datetime, timezone, timedelta

STATUSES={'pending':'출고 대기','shortage':'재고 부족 · 출고 보류','erp_completed':'ERP 출고 완료'}

class Shipments:
    def __init__(self,path):
        self.path=path
        with sqlite3.connect(self.path) as db:
            db.execute('CREATE TABLE IF NOT EXISTS shipment_batches (id TEXT PRIMARY KEY, request_key TEXT UNIQUE NOT NULL, signature TEXT NOT NULL, created TEXT NOT NULL)')
            db.execute('CREATE TABLE IF NOT EXISTS shipment_changes (id INTEGER PRIMARY KEY AUTOINCREMENT, created TEXT NOT NULL, kind TEXT NOT NULL, before_json TEXT NOT NULL, undone INTEGER NOT NULL DEFAULT 0)')
            db.execute('CREATE TABLE IF NOT EXISTS shipments (id INTEGER PRIMARY KEY AUTOINCREMENT, batch_id TEXT NOT NULL, yard TEXT NOT NULL, status TEXT NOT NULL, memo TEXT NOT NULL DEFAULT \'\', payload TEXT NOT NULL)')
            columns={r[1] for r in db.execute('PRAGMA table_info(shipments)')}
            for column,definition in [('deleted','INTEGER NOT NULL DEFAULT 0'),('archived_id','TEXT')]:
                if column not in columns:db.execute(f'ALTER TABLE shipments ADD COLUMN {column} {definition}')
    def _capture(self,db,ids,kind):
        p=','.join('?' for _ in ids)
        db.row_factory=sqlite3.Row
        rows=[dict(r) for r in db.execute(f'SELECT * FROM shipments WHERE id IN ({p}) AND archived_id IS NULL',ids)]
        db.row_factory=None
        if len(rows)!=len(set(ids)):raise ValueError('일부 항목이 마감됐거나 없습니다. 다시 조회하세요.')
        db.execute('INSERT INTO shipment_changes(created,kind,before_json) VALUES(?,?,?)',(datetime.now(timezone(timedelta(hours=9))).isoformat(),kind,json.dumps(rows,ensure_ascii=False)))
    def existing(self,key,signature):
        with sqlite3.connect(self.path) as db:
            r=db.execute('SELECT id,signature FROM shipment_batches WHERE request_key=?',(key,)).fetchone()
            if r:
                if r[1]!=signature:raise ValueError('이미 사용된 확정 요청입니다. 다시 추출한 뒤 확정하세요.')
                count=db.execute('SELECT COUNT(*) FROM shipments WHERE batch_id=?',(r[0],)).fetchone()[0]
                return {'batch_id':r[0],'count':count,'inserted':False}
    def confirm(self,key,signature,yard,records):
        if not records:raise ValueError('확정할 추출 결과가 없습니다.')
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            prior=db.execute('SELECT id,signature FROM shipment_batches WHERE request_key=?',(key,)).fetchone()
            if prior:
                if prior[1]!=signature:raise ValueError('이미 사용된 확정 요청입니다. 다시 추출하세요.')
                count=db.execute('SELECT COUNT(*) FROM shipments WHERE batch_id=?',(prior[0],)).fetchone()[0]
                return {'batch_id':prior[0],'count':count,'inserted':False}
            batch=uuid.uuid4().hex;stamp=datetime.now(timezone(timedelta(hours=9))).isoformat()
            db.execute('INSERT INTO shipment_batches VALUES(?,?,?,?)',(batch,key,signature,stamp))
            db.executemany('INSERT INTO shipments(batch_id,yard,status,memo,payload) VALUES(?,?,?,?,?)',[(batch,r.get('yard',yard),r.get('import_status','pending'),'',json.dumps(r,ensure_ascii=False)) for r in records])
            return {'batch_id':batch,'count':len(records),'inserted':True}
    def rows(self,q='',yard='',status='',date_from='',date_to=''):
        with sqlite3.connect(self.path) as db:
            rows=db.execute('SELECT s.id,s.batch_id,s.yard,s.status,s.memo,s.payload,b.created FROM shipments s JOIN shipment_batches b ON b.id=s.batch_id WHERE s.deleted=0 AND s.archived_id IS NULL ORDER BY b.rowid DESC, s.id ASC').fetchall()
        from .shipment_totals import refresh_totals
        decoded=[{'id':id,'batch_id':batch,'yard':y,'status':status,'memo':memo,'created':created,**json.loads(payload)} for id,batch,y,status,memo,payload,created in rows]
        refresh_totals(decoded)
        out=[]
        for rec in decoded:
            id,batch,y,s,memo,created=[rec[k] for k in ('id','batch_id','yard','status','memo','created')]
            if yard and y!=yard:continue
            if status and s!=status:continue
            if date_from and created[:10]<date_from:continue
            if date_to and created[:10]>date_to:continue
            if q and q.casefold() not in ' '.join(str(v or '') for v in [y,memo,*rec['values']]).casefold():continue
            out.append({'id':id,'batch_id':batch,'yard':y,'status':s,'memo':memo,'created':created,**rec})
        return out
    def update(self,ids,status=None,memo=None):
        if not ids:raise ValueError('출고내역을 선택하세요.')
        if status is not None and status not in STATUSES:raise ValueError('출고 상태가 올바르지 않습니다.')
        if status is None and memo is None:raise ValueError('변경할 상태 또는 메모를 입력하세요.')
        ids=sorted(set(ids))
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            placeholders=','.join('?' for _ in ids)
            count=db.execute(f'SELECT COUNT(*) FROM shipments WHERE id IN ({placeholders}) AND deleted=0 AND archived_id IS NULL',ids).fetchone()[0]
            if count!=len(ids):raise ValueError('일부 출고내역을 찾지 못했습니다. 다시 조회하세요.')
            self._capture(db,ids,'상태·메모 변경')
            fields=[];values=[]
            if status is not None:fields.append('status=?');values.append(status)
            if memo is not None:fields.append('memo=?');values.append(memo)
            db.execute(f'UPDATE shipments SET {", ".join(fields)} WHERE id IN ({placeholders})',values+ids)
        return count

    def import_records(self,key,signature,yard,records):
        if any(r.get('import_status') not in STATUSES for r in records):raise ValueError('기존 내역의 상태를 확인하세요.')
        # 같은 원본 재등록은 중복 생성하지 않고, 구버전에 없던 병합 구간만 복원합니다.
        from .engine import text
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            batch=db.execute('SELECT id,signature FROM shipment_batches WHERE request_key=?',(key,)).fetchone()
            if batch:
                if batch[1]!=signature:raise ValueError('이미 가져온 파일의 조선소 표시가 다릅니다. 기존 설정을 확인하세요.')
                rows=db.execute('SELECT id,payload,archived_id,deleted FROM shipments WHERE batch_id=? ORDER BY id',(batch[0],)).fetchall()
                if len(rows)!=len(records):raise ValueError('기존 원본 행 수가 다릅니다. 중복 등록하지 않았습니다.')
                pairs=[(row,json.loads(row[1]),record) for row,record in zip(rows,records)]
                if any(any(text(old['values'][i])!=text(new['values'][i]) for i in (0,1,2,3,5)) for row,old,new in pairs):raise ValueError('원본 행 구성이 다릅니다. 기존 내역을 유지했습니다.')
                edited={new.get('import_total_group') for row,old,new in pairs if old['values'][4]!=new['values'][4] or row[3] or old.get('import_total_edited')}
                restored=0
                for row,old,new in pairs:
                    if row[2] or old.get('import_total_group'):continue
                    group=new.get('import_total_group')
                    if not group:continue
                    old['import_total_group']=group;old['total_origin']='excel'
                    if group in edited:old['import_total_edited']=True
                    db.execute('UPDATE shipments SET payload=? WHERE id=?',(json.dumps(old,ensure_ascii=False),row[0]));restored+=1
                return {'batch_id':batch[0],'count':len(rows),'inserted':False,'restored_groups':restored}
        return self.confirm(key,signature,yard,records)

    def edit(self,ids,qty=None,delete=False):
        from .order_edits import quantity
        ids=sorted(set(ids))
        if not ids:raise ValueError('항목을 선택하세요.')
        q=quantity(qty) if not delete else None
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            marks=','.join('?' for _ in ids)
            chosen=db.execute(f'SELECT id,batch_id,deleted,archived_id FROM shipments WHERE id IN ({marks})',ids).fetchall()
            if len(chosen)!=len(ids) or any(r[2] or r[3] for r in chosen):raise ValueError('일부 항목이 삭제·마감됐거나 없습니다. 다시 조회하세요.')
            batches={r[1] for r in chosen};affected=[]
            for batch in batches:affected.extend(r[0] for r in db.execute('SELECT id FROM shipments WHERE batch_id=? AND deleted=0 AND archived_id IS NULL',(batch,)))
            self._capture(db,affected,'행 삭제' if delete else '수량 수정')
            groups=set()
            for id in ids:
                rec=json.loads(db.execute('SELECT payload FROM shipments WHERE id=?',(id,)).fetchone()[0])
                if 'import_status' in rec and rec.get('import_total_group'):groups.add(rec['import_total_group'])
            for id in ids:
                if delete:db.execute('UPDATE shipments SET deleted=1 WHERE id=?',(id,))
                else:
                    row=db.execute('SELECT payload FROM shipments WHERE id=?',(id,)).fetchone();rec=json.loads(row[0]);rec['values'][4]=q
                    if 'import_status' in rec:
                        if not rec.get('import_total_group'):rec['import_total_group']='edited-row:'+str(id)
                        rec['import_total_edited']=True
                    db.execute('UPDATE shipments SET payload=? WHERE id=?',(json.dumps(rec,ensure_ascii=False),id))
            for id in affected:
                rec=json.loads(db.execute('SELECT payload FROM shipments WHERE id=?',(id,)).fetchone()[0])
                if rec.get('import_total_group') in groups:
                    rec['import_total_edited']=True;db.execute('UPDATE shipments SET payload=? WHERE id=?',(json.dumps(rec,ensure_ascii=False),id))
            # 원 단위 조정이 필요한 같은 확정 묶음도 함께 보관·재계산하여 되돌리기를 보장합니다.
            from .pricing import recalculate
            for batch in batches:
                priced=[(id,json.loads(payload)) for id,payload in db.execute('SELECT id,payload FROM shipments WHERE batch_id=? AND deleted=0 AND archived_id IS NULL ORDER BY id',(batch,))]
                priced=[(id,rec) for id,rec in priced if 'pricing' in rec]
                recalculate([rec for id,rec in priced])
                for id,rec in priced:db.execute('UPDATE shipments SET payload=? WHERE id=?',(json.dumps(rec,ensure_ascii=False),id))
        return len(ids)
    def undo(self):
        with sqlite3.connect(self.path) as db:
            db.execute('BEGIN IMMEDIATE')
            action=db.execute('SELECT id,kind,before_json FROM shipment_changes WHERE undone=0 ORDER BY id DESC LIMIT 1').fetchone()
            if not action:raise ValueError('되돌릴 출고내역 작업이 없습니다.')
            rows=json.loads(action[2])
            for r in rows:
                current=db.execute('SELECT archived_id FROM shipments WHERE id=?',(r['id'],)).fetchone()
                if not current or current[0]:raise ValueError('해당 항목이 주간 마감됐습니다. 마감된 자료는 백업 파일에서 확인하세요.')
            for r in rows:db.execute('UPDATE shipments SET status=?,memo=?,payload=?,deleted=? WHERE id=?',(r['status'],r['memo'],r['payload'],r.get('deleted',0),r['id']))
            db.execute('UPDATE shipment_changes SET undone=1 WHERE id=?',(action[0],))
        return action[1]
