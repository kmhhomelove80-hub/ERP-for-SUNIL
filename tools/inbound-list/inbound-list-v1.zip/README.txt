# 입고LIST 웹 실행파일

[inbound-list.html 다운로드](https://github.com/kmhhomelove80-hub/ERP-for-SUNIL/raw/refs/heads/main/tools/inbound-list/inbound-list.html)

파일을 내려받아 Chrome 또는 Edge에서 열어 실행하세요. 서버·설치·인터넷 연결이 필요 없습니다.

1. ERP 재고이동 XLS/XLSX/CSV/TSV 파일을 선택합니다.
2. 분할 수량(예: 20+8)과 최종 비고를 입력합니다.
3. 미리보기를 확인하고 엑셀 다운로드 또는 인쇄/PDF를 선택합니다.

합계 행은 자동 제외하고 원본 상세 행을 유지합니다. 분할 합계가 원본 수량과 다르면 출력을 차단합니다. ERP 적요·비고는 참고용으로 표시하며 최종 비고는 직접 입력합니다. 문서 날짜는 기본 실행일이며 수정할 수 있습니다. XLSX의 첫 시트를 읽고 파일 크기는 20MB 이하를 지원합니다.

업로드 자료는 브라우저 메모리에서 처리하며 서버로 전송하지 않습니다. 새로고침 전 엑셀로 저장하세요. 포함된 예제는 가상 데이터입니다.

검증: 실제 CP949 ERP 파일에서 상세 21행, 18품목, 277개 확인; 분할 검증 및 XLSX 재읽기 통과. 브라우저 화면·실제 인쇄는 미검증입니다.

SheetJS Community Edition 0.18.5 (Apache-2.0)를 포함합니다.
