import unittest,tempfile,sqlite3,json
from pathlib import Path
from copy import deepcopy
from app.engine import extract_selected,convert_erp
from app.pricing import attach_pricing,apply_quantities
from app.bridge import Bridge,canonical
from app.shipments import Shipments
from app.store import Store
import hmac,hashlib,base64,gzip

def erp(qty=10,remaining=4,amount=1000000,tax=100000,code='CODE'):
 return ['현대중공업','대형','3449','3449P','',4,5,0,'3449P',code,'2026-01-01',1,remaining,amount,tax,amount+tax if tax is not None else None,'2026-12-01','조명',qty,None]
def order(q,block='A'):
 return {'yard':'HHI','values':['3449P','3449',block,'조명',q,'CODE',None,'담당/일반/일자','2026-01-01',1,'창고','2026-12-01']}
class PricingTests(unittest.TestCase):
 def test_original_quantity_not_remaining(self):
  result=extract_selected([order(2,'A'),order(3,'B'),order(5,'C')],[erp()]);self.assertEqual([x['values'][12] for x in result['rows']],[200000,300000,500000]);self.assertEqual(sum(r['values'][12] for r in result['rows']),1000000)
 def test_consolidation_and_override_reprice(self):
  result=extract_selected([order(2),order(3)],[erp()]);self.assertEqual(result['rows'][0]['values'][12:],[500000,50000,550000]);apply_quantities(result,{0:7});self.assertEqual(result['rows'][0]['values'][4:7],[7,'CODE',7]);self.assertEqual(result['rows'][0]['values'][12:],[700000,70000,770000])
 def test_original_zero_does_not_fallback_to_remaining(self):
  r=extract_selected([order(2)],[erp(qty=0)]);self.assertEqual(r['rows'][0]['values'][12:],[None]*3);self.assertIn('원수주수량',r['rows'][0]['pricing']['reason'])
 def test_conflicting_unit_prices_not_arbitrarily_selected(self):
  r=extract_selected([order(2)],[erp(),erp(amount=2000000)]);self.assertEqual(r['rows'][0]['values'][12],None);self.assertIn('서로 다른',r['rows'][0]['pricing']['reason'])
 def test_same_price_multiple_erp_rows_allowed(self):
  r=extract_selected([order(2)],[erp(),erp(qty=5,amount=500000,tax=50000)]);self.assertEqual(r['rows'][0]['values'][12],200000)
 def test_unknown_tax_not_assumed(self):
  e=erp(tax=None);e[15]=None;r=extract_selected([order(2)],[e]);self.assertEqual(r['rows'][0]['values'][12:],[200000,None,None])
 def test_exempt_tax_zero(self):
  r=extract_selected([order(2)],[erp(tax=0)]);self.assertEqual(r['rows'][0]['values'][12:],[200000,0,200000])
 def test_wrong_yard_not_used(self):
  e=erp();e[0]='현대삼호중공업';r=extract_selected([order(2)],[e]);self.assertIsNone(r['rows'][0]['values'][12])
 def test_wrong_code_not_used(self):
  r=extract_selected([order(2)],[erp(code='OTHER')]);self.assertIsNone(r['rows'][0]['values'][12])
 def test_rounding_budget(self):
  r=extract_selected([order(1,'A'),order(1,'B'),order(1,'C')],[erp(qty=3,amount=100,tax=10)]);self.assertEqual(sum(x['values'][12] for x in r['rows']),100);self.assertEqual(sum(x['values'][13] for x in r['rows']),10)
 def test_explicit_unit(self):
  e=erp();e[19]=90000;r=extract_selected([order(2)],[e]);self.assertEqual(r['rows'][0]['values'][12],180000)
 def test_conversion_keeps_original_quantity_separate(self):
  headers=[None]*36;headers[2]='품목코드';headers[9]='현장명';row=[None]*36
  for c,v in {1:'고객',3:'CODE',8:'3449P',10:'3449',21:10,22:4,28:1000000}.items():row[c-1]=v
  e=convert_erp({'REF':[['거래처','조선소','구분'],['고객','현대중공업','대형']]},[headers,row])[0];self.assertEqual((e[12],e[18]),(4,10))
 def test_quantity_rejects_nan_and_negative(self):
  for q in [-1,float('nan'),float('inf')]:
   with self.assertRaises(ValueError):apply_quantities(extract_selected([order(2)],[erp()]),{0:q})
 def test_bridge_split_prorates_money(self):
  with tempfile.TemporaryDirectory() as d:
   path=Path(d)/'test.db';Store(path);b=Bridge(path);b.set_url('http://127.0.0.1:8080/picking/new/');r=extract_selected([order(10)],[erp()]);s=b.send('quantity-key-123456','x',r['rows'],'http://127.0.0.1:8000/');f=json.loads(gzip.decompress(base64.urlsafe_b64decode(s['url'].split('#sunil_forward=')[1]+'='*((4-len(s['url'].split('#sunil_forward=')[1])%4)%4))));body={'transfer_id':s['id'],'erp_order_id':s['id'],'rows':[{'line_id':0,'requested':10,'allocated':7,'shortage':3}]};b.receive({'body':body,'signature':hmac.new(bytes.fromhex(f['secret']),canonical(body),hashlib.sha256).hexdigest()});b.confirm(s['id']);rows=Shipments(path).rows();self.assertEqual([(x['values'][4],x['values'][12]) for x in rows],[(7,700000),(3,300000)])
 def test_shipment_edit_group_rounding_and_undo(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d)/'test.db';Store(p);ledger=Shipments(p);result=extract_selected([order(1,'A'),order(1,'B'),order(1,'C')],[erp(qty=3,amount=100,tax=10)]);ledger.confirm('rounding-request-123456','hash','HHI',result['rows']);before=ledger.rows();ledger.edit([before[0]['id']],2);after=ledger.rows();self.assertEqual(sum(r['values'][12] for r in after),133);self.assertEqual(after[0]['values'][6],4);ledger.undo();self.assertEqual(ledger.rows(),before)
