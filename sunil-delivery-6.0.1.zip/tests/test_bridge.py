import tempfile,hmac,hashlib,json,base64,gzip
from pathlib import Path
from unittest import TestCase
from app.store import Store
from app.bridge import Bridge,canonical
from app.shipments import Shipments

class BridgeTests(TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.path=Path(self.tmp.name)/'db';Store(self.path);self.bridge=Bridge(self.path);self.bridge.set_url('http://127.0.0.1:8080/picking/new/')
  self.rows=[{'yard':'HMD','values':['P','8444','A500','조명',10,'CODE',10,None,'2026-01-01',1,'창고','2026-11-01',100,10,110],'unmatched':False}]
  self.sent=self.bridge.send('request-key-123456','hash',self.rows,'http://127.0.0.1:8000/')
  token=self.sent['url'].split('#sunil_forward=')[1];self.forward=json.loads(gzip.decompress(base64.urlsafe_b64decode(token+'='*((4-len(token)%4)%4))))
 def envelope(self,allocated=7,shortage=3):
  body={'transfer_id':self.sent['id'],'erp_order_id':self.sent['id'],'rows':[{'line_id':0,'requested':10,'allocated':allocated,'shortage':shortage}]}
  return {'body':body,'signature':hmac.new(bytes.fromhex(self.forward['secret']),canonical(body),hashlib.sha256).hexdigest()}
 def test_forward_contains_seven_columns(self):self.assertEqual(len(self.forward['rows'][0]['values']),7)
 def test_send_idempotent(self):self.assertEqual(self.sent['id'],self.bridge.send('request-key-123456','hash',self.rows,'http://127.0.0.1:8000/')['id'])
 def test_partial_reply_splits_status_and_quantity(self):
  result=self.bridge.receive(self.envelope());self.assertEqual((result['allocated'],result['shortage']),(7,3));self.bridge.confirm(self.sent['id'])
  rows=Shipments(self.path).rows();self.assertEqual({r['status']:r['values'][4] for r in rows},{'pending':7,'shortage':3})
 def test_all_shortage(self):
  self.bridge.receive(self.envelope(0,10));self.bridge.confirm(self.sent['id']);rows=Shipments(self.path).rows();self.assertEqual(len(rows),1);self.assertEqual(rows[0]['status'],'shortage')
 def test_replay_does_not_duplicate(self):
  self.bridge.receive(self.envelope());self.bridge.receive(self.envelope());self.bridge.confirm(self.sent['id']);self.assertFalse(self.bridge.confirm(self.sent['id'])['inserted']);self.assertEqual(len(Shipments(self.path).rows()),2)
 def test_signature_tamper_rejected(self):
  value=self.envelope();value['body']['rows'][0]['allocated']=8
  with self.assertRaises(ValueError):self.bridge.receive(value)
  self.assertEqual(self.bridge.result(self.sent['id'])['status'],'pending')
 def test_conservation_rejected_even_with_signature(self):
  with self.assertRaises(ValueError):self.bridge.receive(self.envelope(8,3))
 def test_different_result_not_overwritten(self):
  self.bridge.receive(self.envelope())
  with self.assertRaises(ValueError):self.bridge.receive(self.envelope(8,2))
 def test_pending_cannot_confirm(self):
  with self.assertRaises(ValueError):self.bridge.confirm(self.sent['id'])
 def test_snapshots_survive_restart(self):
  self.bridge.receive(self.envelope());self.assertEqual(Bridge(self.path).result(self.sent['id'])['shortage'],3)
 def test_missing_code_blocks_entire_send(self):
  self.rows[0]['values'][5]=''
  with self.assertRaises(ValueError):self.bridge.send('other-key-123456','other',self.rows,'http://127.0.0.1:8000/')
 def test_set_notes_preserved_in_partial_split(self):
  import sqlite3
  self.bridge.receive(self.envelope())
  with sqlite3.connect(self.path) as db:
   row=db.execute('SELECT snapshot FROM bridge_transfers WHERE id=?',(self.sent['id'],)).fetchone();records=json.loads(row[0]);records[0]['values'][7]='담당자/긴급/2026-11-05';db.execute('UPDATE bridge_transfers SET snapshot=? WHERE id=?',(json.dumps(records,ensure_ascii=False),self.sent['id']))
  self.bridge.confirm(self.sent['id']);self.assertTrue(all(r['values'][7]=='담당자/긴급/2026-11-05' for r in Shipments(self.path).rows()))
 def test_delete_pending_rejects_late_reply(self):
  self.bridge.delete([self.sent['id']]);self.assertEqual(self.bridge.recent(),[])
  with self.assertRaisesRegex(ValueError,'삭제된'):self.bridge.receive(self.envelope())
  with self.assertRaises(ValueError):self.bridge.result(self.sent['id'])
  with self.assertRaises(ValueError):self.bridge.confirm(self.sent['id'])
 def test_delete_confirmed_preserves_shipments(self):
  self.bridge.receive(self.envelope());self.bridge.confirm(self.sent['id']);before=Shipments(self.path).rows();self.bridge.delete([self.sent['id']]);self.assertEqual(Shipments(self.path).rows(),before)
 def test_delete_atomic_missing_id(self):
  with self.assertRaises(ValueError):self.bridge.delete([self.sent['id'],'missing'])
  self.assertEqual(self.bridge.result(self.sent['id'])['status'],'pending')
 def test_deleted_idempotency_key_cannot_resend(self):
  self.bridge.delete([self.sent['id']])
  with self.assertRaises(ValueError):self.bridge.send('request-key-123456','hash',self.rows,'http://127.0.0.1:8000/')
