/* 두 앱은 독립 유지. 전송 자료와 회신은 브라우저 해시를 거쳐 각 앱이 검증합니다. */
let activeTransfer=null,transferRequestKey=null,transferExtractionSignature=null;
const bridgePriorButtons=buttons,bridgePriorInvalidate=invalidate,bridgePriorConfirm=$('confirmExtract').onclick;
const sendERP=newButton('sendERP','ERP로 보내기'),resultERP=newButton('resultERP','ERP 결과','예약 결과 및 최근 전송'),settingsERP=newButton('settingsERP','⚙','ERP 접속 주소 설정','secondary icon-button');$('confirmExtract').parentElement.prepend(sendERP,resultERP,settingsERP);
buttons=function(){bridgePriorButtons();sendERP.disabled=busy||!lastExtract||!!activeTransfer;};
invalidate=function(){bridgePriorInvalidate();activeTransfer=null;transferRequestKey=null;transferExtractionSignature=null;};
function extractionSig(){return JSON.stringify(lastExtract)}
// BEGIN ERP TRANSFER TAB
/* 일반 ERP 탭과 분리된 전송 전용 탭. 서버·자료 형식은 변경하지 않습니다. */
const ERP_TRANSFER_TAB='sunil_delivery_erp_transfer';
let erpTransferWindow=null;
// ERP 예약 회신으로 돌아온 전용 탭도 새로고침 후 같은 이름으로 찾습니다.
if(location.hash.startsWith('#sunil_result='))window.name=ERP_TRANSFER_TAB;
function transferWindow(){
  let w=erpTransferWindow;
  if(!w||w.closed)w=window.open('',ERP_TRANSFER_TAB);
  if(!w)throw Error('ERP 전송 탭을 열 수 없습니다. 팝업을 허용해 주세요.');
  erpTransferWindow=w;
  let fresh=false;
  try{fresh=w.location.href==='about:blank'}catch{/* 다른 주소의 ERP 입력 내용은 읽지 않습니다. */}
  if(!fresh&&!confirm('전송용 ERP 탭의 내용을 교체하시겠습니까?\n아직 예약 등록하지 않은 입력은 사라질 수 있습니다. 필요하면 먼저 ERP에서 예약 등록을 완료하세요.'))return null;
  if(fresh){w.document.title='ERP 전송 준비';w.document.body.textContent='ERP 전송 자료를 준비하고 있습니다…';}
  return {
    navigate(url){if(w.closed)throw Error('ERP 전송 탭이 닫혔습니다. 다시 전송해 주세요.');w.location.replace(url);try{w.focus()}catch{}},
    abort(){if(fresh&&!w.closed)w.close();}
  };
}
// END ERP TRANSFER TAB
sendERP.onclick=()=>{if(busy||!lastExtract)return;let w;try{w=transferWindow();if(!w)return}catch(e){notice(e.message,true);return}work(async()=>{try{const signature=extractionSig();if(signature!==transferExtractionSignature){transferRequestKey=crypto.randomUUID();transferExtractionSignature=signature}const d=await(await api('/api/bridge/send',post({...lastExtract,request_key:transferRequestKey,reply_url:location.origin+'/'}))).json();w.navigate(d.url);activeTransfer=d.id;await showTransfer(d.id);notice(`${d.count}행의 7열 자료를 ERP로 보냈습니다. ERP에서 로그인·배정 미리보기·예약 등록을 완료하면 결과가 돌아옵니다.`);}catch(e){w.abort();throw e}})};
const settingDialog=dialog('erpSettingDialog','ERP 연결 주소'),urlLabel=el('label','ERP 피킹 요청 주소'),urlInput=el('input');urlInput.type='url';urlInput.placeholder='http://ERP서버주소:포트/picking/new/';urlInput.style.width='100%';const saveERP=newButton('saveERPURL','주소 저장');settingDialog.append(urlLabel,urlInput,saveERP,el('p','현재 추출 결과의 POR·호선·블록·품명·수량·ERP CODE·합계를 전송합니다. ERP 수신부 업데이트가 먼저 필요합니다. 로그인 정보는 저장하거나 전달하지 않습니다.'));saveERP.style.marginTop='12px';settingsERP.onclick=()=>work(async()=>{const d=await(await api('/api/bridge')).json();urlInput.value=d.url;openDialog(settingDialog)});saveERP.onclick=()=>work(async()=>{await api('/api/bridge/url',post({url:urlInput.value}));settingDialog.close();notice('ERP 접속 주소를 저장했습니다.');});
const recentDialog=dialog('erpResultDialog','ERP 예약 결과·최근 전송'),recentTable=el('div');recentTable.className='tablewrap';recentDialog.append(recentTable);
function clearDeletedTransfer(ids){if(!activeTransfer||!ids.includes(activeTransfer))return;activeTransfer=null;lastExtract=null;transferRequestKey=null;transferExtractionSignature=null;$('confirmExtract').dataset.bridge='';$('extractTable').replaceChildren(el('div','ERP 전송 기록을 삭제했습니다. 필요한 자료는 다시 추출하세요.'));$('extractStats').replaceChildren();$('extractWarnings').replaceChildren();buttons();}
window.addEventListener('storage',event=>{if(event.key==='sunil.deletedTransfers'){try{clearDeletedTransfer(JSON.parse(event.newValue).ids)}catch{}}});
async function listTransfers(){
 const d=await(await api('/api/bridge')).json(),labels={pending:'회신 대기',received:'예약 결과 수신',confirmed:'출고내역 반영 완료'},selected=new Set();
 const bar=el('div');bar.className='bridge-delete-tools';const hint=el('small','수주관리 기록만 삭제합니다. ERP 예약과 확정 출고내역은 유지됩니다.');const remove=newButton('deleteERPTransfers','선택 삭제');bar.append(hint,remove);
 const t=makeTable(['선택','전송일','전송번호','상태','결과','ERP','삭제'],d.transfers.map(r=>['',new Date(r.created).toLocaleString('ko-KR'),r.id.slice(0,10),labels[r.status],'','','']));
 const all=el('input');all.type='checkbox';all.className='bridge-check';all.setAttribute('aria-label','전송 기록 전체 선택');t.querySelector('th').replaceChildren(all);
 function sync(){remove.disabled=busy||!selected.size;all.checked=d.transfers.length>0&&selected.size===d.transfers.length;all.indeterminate=selected.size>0&&selected.size<d.transfers.length;}
 async function erase(ids){if(!ids.length)return;if(!confirm(`${ids.length}건의 ERP 전송 기록을 삭제하시겠습니까?\n회신 대기도 종료하며 이후 회신을 반영하지 않습니다.\nERP의 예약과 이미 확정된 출고내역은 삭제되지 않습니다.`))return;
  await api('/api/bridge/delete',post({ids}));clearDeletedTransfer(ids);try{localStorage.setItem('sunil.deletedTransfers',JSON.stringify({ids,at:Date.now()}))}catch{}await listTransfers();notice('ERP 전송 기록을 삭제했습니다. ERP 예약과 확정 출고내역은 유지됩니다.');
 }
 const checks=[];t.querySelectorAll('tbody tr').forEach((tr,i)=>{const r=d.transfers[i],check=el('input');check.type='checkbox';check.className='bridge-check';check.setAttribute('aria-label',r.id.slice(0,10)+' 전송 선택');check.onchange=()=>{if(check.checked)selected.add(r.id);else selected.delete(r.id);sync()};checks.push(check);tr.children[0].append(check);
  const open=newButton('','결과 열기');open.onclick=()=>work(async()=>{recentDialog.close();await showTransfer(r.id)});tr.children[4].append(open);
  const again=newButton('','ERP 다시 열기');again.onclick=()=>{let w;try{w=transferWindow();if(!w)return}catch(e){notice(e.message,true);return}work(async()=>{try{const result=await(await api('/api/bridge/reopen/'+r.id,{method:'POST'})).json();w.navigate(result.url)}catch(e){w.abort();throw e}})};tr.children[5].append(again);
  const del=newButton('','삭제');del.onclick=()=>work(()=>erase([r.id]));tr.children[6].append(del);
 });
 all.onchange=()=>{selected.clear();checks.forEach((c,i)=>{c.checked=all.checked;if(c.checked)selected.add(d.transfers[i].id)});sync()};remove.onclick=()=>work(()=>erase([...selected]));recentTable.replaceChildren(bar,t);sync();
}
resultERP.onclick=()=>work(async()=>{await listTransfers();openDialog(recentDialog)});
async function showTransfer(id){const d=await(await api('/api/bridge/result/'+id)).json();activeTransfer=id;await showTab('extract');const headers=['조선소','POR번호','호선','블록','품명','요청 수량','ERP CODE','합계','SET','배정 수량','부족 수량'];const rows=d.rows.map(r=>[r.yard,...r.values.slice(0,8),r.allocation?.allocated??'미회신',r.allocation?.shortage??'미회신']);$('extractTable').replaceChildren(makeTable(headers,rows));$('extractStats').replaceChildren(...[['요청',d.requested],['배정',d.allocated??'대기'],['부족',d.shortage??'대기']].map(([label,v])=>{const e=el('div');e.className='stat';e.append(el('span',label),el('b',format(v)));return e}));$('extractWarnings').replaceChildren(el('div',d.status==='pending'?'ERP 예약 등록 완료 결과를 기다리고 있습니다.':d.status==='confirmed'?'이 예약 결과는 이미 출고내역에 반영됐습니다.':'ERP 예약이 완료됐습니다. 출고내역 확정 시 배정 수량은 출고 대기, 부족 수량은 재고 부족·출고 보류로 나눕니다.'));$('extractWarnings').firstChild.className='notice';shipmentConfirmed=d.status==='confirmed';lastExtract=null;shipmentConfirmKey=null;fitTable($('extractTable'));adjustTables();buttons();$('confirmExtract').disabled=busy||d.status!=='received';$('confirmExtract').dataset.bridge=d.status==='received'?id:'';}
const bridgeBeforeButtons=buttons;buttons=function(){bridgeBeforeButtons();if(activeTransfer)$('confirmExtract').disabled=busy||!$('confirmExtract').dataset.bridge;};
$('confirmExtract').onclick=()=>{if(!activeTransfer||!$('confirmExtract').dataset.bridge){bridgePriorConfirm();return}work(async()=>{if(!confirm('ERP 배정 수량은 출고 대기, 부족 수량은 출고 보류로 나누어 누적합니다. 확정하시겠습니까?'))return;if(typeof flushBridgeNotes==='function')await flushBridgeNotes(activeTransfer);const d=await(await api('/api/bridge/confirm',post({id:activeTransfer}))).json();$('confirmExtract').dataset.bridge='';shipmentConfirmed=true;await showTab('shipments');notice(d.inserted?`${d.count}행을 ERP 예약 결과에 따라 출고내역으로 등록했습니다.`:'이미 반영된 ERP 예약 결과입니다. 중복 등록하지 않았습니다.');});};
// 일반 추출을 다시 실행하면 이전 ERP 결과 화면 연결을 해제합니다.
const bridgePriorDisplay=displayExtract;displayExtract=async function(req){activeTransfer=null;$('confirmExtract').dataset.bridge='';transferRequestKey=null;transferExtractionSignature=null;await bridgePriorDisplay(req);};
async function receiveFragment(){if(!location.hash.startsWith('#sunil_result='))return;const token=location.hash.slice(14);if(token.length>180000)throw Error('ERP 회신 크기가 너무 큽니다.');const raw=Uint8Array.from(atob(token.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-token.length%4)%4)),c=>c.charCodeAt(0));const reader=new Blob([raw]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();const pieces=[];let size=0;while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>1200000){reader.cancel();throw Error('ERP 회신 크기가 너무 큽니다.')}pieces.push(value)}const envelope=JSON.parse(await new Blob(pieces).text());let d;try{d=await(await api('/api/bridge/reply',post({envelope}))).json()}catch(e){if(e.message.includes('삭제된')){history.replaceState(null,'',location.pathname+location.search);clearDeletedTransfer([envelope.body?.transfer_id]);notice('삭제된 전송의 회신이므로 반영하지 않았습니다. ERP 예약은 ERP에서 확인하세요.',true);return}throw e}history.replaceState(null,'',location.pathname+location.search);await showTransfer(d.id);notice('ERP 예약 결과를 받았습니다. 배정·부족 수량을 확인하고 출고내역 확정을 누르세요.');}
async function afterReady(fn){while(busy)await new Promise(resolve=>setTimeout(resolve,100));work(fn)}
if(location.hash.startsWith('#sunil_result='))afterReady(receiveFragment);
window.addEventListener('focus',()=>{if(activeTransfer&&!busy)work(async()=>{const d=await(await api('/api/bridge/result/'+activeTransfer)).json();if(d.status!=='pending')await showTransfer(d.id)})});
buttons();
