"""분리된 ERP와 전송번호·행번호로 연결하는 예약 결과 왕복."""
import base64,gzip,hashlib,hmac,json,secrets,sqlite3,time,uuid,math
from urllib.parse import urlsplit,urlunsplit
from pydantic import BaseModel,Field
from .engine import text,product_key
from .shipments import Shipments
from .closing import now

DEFAULT_ERP=''
MAX=2147483647

def canonical(value):return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def packed(value):return base64.urlsafe_b64encode(gzip.compress(canonical(value),mtime=0)).decode().rstrip('=')
def valid_url(value,reply=False):
 p=urlsplit(value)
 if p.scheme not in ('http','https') or not p.hostname or p.username or p.password or p.query or p.fragment:raise ValueError('http 또는 https 접속 주소를 입력하세요. 사용자정보·쿼리·해시는 사용할 수 없습니다.')
 if reply and p.path not in ('','/'):raise ValueError('회신 주소는 수주관리의 기본 접속 주소여야 합니다.')
 if not reply and not p.path.endswith('/picking/new/'):raise ValueError('ERP 주소는 /picking/new/ 화면이어야 합니다.')
 return urlunsplit((p.scheme,p.netloc,p.path or '/', '', ''))
def integer(v,positive=False):
 if isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) or v!=int(v) or not (1 if positive else 0)<=v<=MAX:raise ValueError('ERP 전송 수량·합계는 양의 정수여야 합니다. 0·소수·범위 초과 수량을 확인하세요.')
 return int(v)

class Bridge:
 def __init__(self,path):
  self.path=path;Shipments(path)
  with sqlite3.connect(path) as db:
   db.execute('CREATE TABLE IF NOT EXISTS bridge_transfers(id TEXT PRIMARY KEY,request_key TEXT UNIQUE,request_hash TEXT,secret TEXT,created TEXT,forward TEXT,snapshot TEXT,reply TEXT,status TEXT,batch_id TEXT)')
   db.execute('CREATE TABLE IF NOT EXISTS preferences(key TEXT PRIMARY KEY,value TEXT NOT NULL)')
 def url(self):
  with sqlite3.connect(self.path) as db:r=db.execute("SELECT value FROM preferences WHERE key='erp_url'").fetchone()
  return r[0] if r else DEFAULT_ERP
 def set_url(self,value):
  value=valid_url(value)
  with sqlite3.connect(self.path) as db:db.execute("INSERT INTO preferences VALUES('erp_url',?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",(value,))
  return value
 def send(self,key,request_hash,rows,reply_url):
  if not self.url():raise ValueError('추출의 ERP 설정에서 접속 주소를 먼저 저장하세요.')
  reply_url=valid_url(reply_url,True)
  if not 1<=len(rows)<=500:raise ValueError('ERP는 한 번에 1~500행을 받습니다. 추출 범위를 줄여 주세요.')
  values=[];errors=[];totals={}
  for i,rec in enumerate(rows):
   r=rec['values'];v=[text(x).replace('\t',' ').replace('\r',' ').replace('\n',' ') for x in r[:7]]
   try:
    qty=integer(r[4],True);total=integer(r[6],True)
    if not v[5] or len(v[5])>100 or v[5].startswith(('=','#')) or any(len(v[j])>2000 for j in range(4)):raise ValueError('ERP CODE 또는 고객 정보를 확인하세요.')
    totals[v[5]]=totals.get(v[5],0)+qty
    if totals[v[5]]>MAX:raise ValueError('품목별 합산 수량이 ERP 허용 범위를 넘습니다.')
    v[4]=qty;v[6]=total;values.append({'line_id':i,'values':v})
   except (ValueError,TypeError):errors.append(str(i+1))
  if errors:raise ValueError('ERP 전송 불가: '+', '.join(errors[:15])+'행의 품목코드·수량·합계를 확인하세요. 수량은 1 이상의 정수여야 합니다.')
  tsv='\n'.join('\t'.join(map(str,r['values'])) for r in values)
  if len(tsv)>300000:raise ValueError('ERP 입력란의 300,000자 제한을 초과했습니다. 추출 범위를 줄이세요.')
  with sqlite3.connect(self.path) as db:
   db.execute('BEGIN IMMEDIATE')
   prior=db.execute('SELECT id,request_hash,forward,status FROM bridge_transfers WHERE request_key=?',(key,)).fetchone()
   if prior:
    if prior[1]!=request_hash:raise ValueError('전송 요청이 변경됐습니다. 다시 추출하세요.')
    f=json.loads(prior[2]);f['issued_at']=int(time.time())
    db.execute('UPDATE bridge_transfers SET forward=? WHERE id=?',(json.dumps(f,ensure_ascii=False),prior[0]))
    return {'id':prior[0],'url':self.url()+'?delivery_id='+prior[0]+'#sunil_forward='+packed(f),'count':len(values),'status':prior[3]}
   id=uuid.uuid4().hex;secret=secrets.token_hex(32)
   hulls=list(dict.fromkeys(text(r['values'][1]) for r in rows if text(r['values'][1])))
   forward={'version':1,'transfer_id':id,'secret':secret,'issued_at':int(time.time()),'reply_url':reply_url,'project':(' / '.join(hulls) or '통합 수주 추출')[:250],'rows':values}
   fragment=packed(forward)
   if len(fragment)>180000:raise ValueError('자동 전송 가능한 크기를 초과했습니다. 추출 행 수를 줄이세요.')
   db.execute('INSERT INTO bridge_transfers VALUES(?,?,?,?,?,?,?,?,?,?)',(id,key,request_hash,secret,now().isoformat(),json.dumps(forward,ensure_ascii=False),json.dumps(rows,ensure_ascii=False),None,'pending',None))
  return {'id':id,'url':self.url()+'?delivery_id='+id+'#sunil_forward='+fragment,'count':len(values),'status':'pending'}
 def receive(self,envelope):
  body=envelope.get('body');signature=envelope.get('signature','')
  if not isinstance(body,dict) or set(body)!={'transfer_id','erp_order_id','rows'}:raise ValueError('ERP 회신 형식이 올바르지 않습니다.')
  with sqlite3.connect(self.path) as db:
   db.execute('BEGIN IMMEDIATE');r=db.execute('SELECT secret,snapshot,reply,status FROM bridge_transfers WHERE id=?',(body['transfer_id'],)).fetchone()
   if not r:raise ValueError('이 PC에 원본 전송 자료가 없습니다. 전송한 수주관리 PC와 data 폴더를 확인하세요.')
   expected=hmac.new(bytes.fromhex(r[0]),canonical(body),hashlib.sha256).hexdigest()
   if not isinstance(signature,str) or not hmac.compare_digest(expected,signature):raise ValueError('ERP 회신 검증에 실패했습니다.')
   if body['erp_order_id'].replace('-','')!=body['transfer_id']:raise ValueError('ERP 예약번호와 원본 전송번호가 다릅니다.')
   snapshot=json.loads(r[1]);items=body['rows']
   if not isinstance(items,list) or len(items)!=len(snapshot):raise ValueError('ERP 회신 행 수가 원본과 다릅니다.')
   seen=set()
   for item in items:
    if set(item)!={'line_id','requested','allocated','shortage'}:raise ValueError('ERP 회신 행 형식이 다릅니다.')
    i=item['line_id']
    if type(i) is not int or not 0<=i<len(snapshot) or i in seen:raise ValueError('중복 또는 잘못된 ERP 회신 행번호입니다.')
    seen.add(i);requested=integer(item['requested'],True);allocated=integer(item['allocated']);shortage=integer(item['shortage'])
    if requested!=snapshot[i]['values'][4] or allocated+shortage!=requested:raise ValueError('ERP 회신 수량이 원본 요청 수량과 일치하지 않습니다.')
   if r[2]:
    if json.loads(r[2])!=body:raise ValueError('이미 다른 결과가 회신됐습니다. 기존 결과를 임의로 덮어쓰지 않습니다.')
   else:db.execute("UPDATE bridge_transfers SET reply=?,status='received' WHERE id=?",(json.dumps(body,ensure_ascii=False),body['transfer_id']))
  return self.result(body['transfer_id'])
 def result(self,id):
  with sqlite3.connect(self.path) as db:r=db.execute('SELECT created,snapshot,reply,status,batch_id FROM bridge_transfers WHERE id=?',(id,)).fetchone()
  if not r:raise ValueError('전송 자료를 찾을 수 없습니다.')
  rows=json.loads(r[1]);reply=json.loads(r[2]) if r[2] else None;details={x['line_id']:x for x in reply['rows']} if reply else {}
  return {'id':id,'created':r[0],'status':r[3],'batch_id':r[4],'rows':[{'line_id':i,**rec,'allocation':details.get(i)} for i,rec in enumerate(rows)],'requested':sum(x['values'][4] for x in rows),'allocated':sum(x['allocated'] for x in details.values()) if reply else None,'shortage':sum(x['shortage'] for x in details.values()) if reply else None,'erp_order_id':reply['erp_order_id'] if reply else None}
 def recent(self):
  with sqlite3.connect(self.path) as db:return [{'id':i,'created':c,'status':s} for i,c,s in db.execute('SELECT id,created,status FROM bridge_transfers ORDER BY rowid DESC LIMIT 30')]
 def confirm(self,id):
  with sqlite3.connect(self.path) as db:
   db.execute('BEGIN IMMEDIATE');r=db.execute('SELECT snapshot,reply,status,batch_id FROM bridge_transfers WHERE id=?',(id,)).fetchone()
   if not r or not r[1]:raise ValueError('ERP 예약 결과 회신 후 출고내역을 확정하세요.')
   if r[3]:return {'batch_id':r[3],'count':db.execute('SELECT COUNT(*) FROM shipments WHERE batch_id=?',(r[3],)).fetchone()[0],'inserted':False}
   source=json.loads(r[0]);body=json.loads(r[1]);by_id={x['line_id']:x for x in body['rows']};records=[]
   for i,rec in enumerate(source):
    line=by_id[i]
    for amount,status in [(line['allocated'],'pending'),(line['shortage'],'shortage')]:
     if amount:
      item={**rec,'values':rec['values'][:],'bridge_transfer_id':id,'erp_order_id':body['erp_order_id'],'bridge_line_id':i};item['values'][4]=amount;records.append((item,status))
   batch=uuid.uuid4().hex;db.execute('INSERT INTO shipment_batches VALUES(?,?,?,?)',(batch,'bridge:'+id,'bridge',now().isoformat()))
   for item,status in records:db.execute('INSERT INTO shipments(batch_id,yard,status,memo,payload) VALUES(?,?,?,?,?)',(batch,item['yard'],status,'ERP 예약 결과 반영',json.dumps(item,ensure_ascii=False)))
   db.execute("UPDATE bridge_transfers SET status='confirmed',batch_id=? WHERE id=?",(batch,id))
  return {'batch_id':batch,'count':len(records),'inserted':True}

class Criterion(BaseModel):por:str='';block:str=''
class Send(BaseModel):
 yard:str=''
 criteria:list[Criterion]=Field(default_factory=list,max_length=5000)
 order_ids:list[str]|None=None
 revision:int
 set_notes:dict[int,str]=Field(default_factory=dict)
 request_key:str=Field(min_length=16,max_length=100)
 reply_url:str=Field(max_length=1000)
class Notes(BaseModel):
 id:str
 notes:dict[int,str]
class Reply(BaseModel):envelope:dict
class Confirm(BaseModel):id:str
class URL(BaseModel):url:str=Field(max_length=1000)

def register_bridge(app,get_store,extraction):
 def service():return Bridge(get_store().path)
 @app.get('/api/bridge')
 def config():return {'url':service().url(),'transfers':service().recent()}
 @app.post('/api/bridge/url')
 def save_url(req:URL):return {'url':service().set_url(req.url)}
 @app.post('/api/bridge/reopen/{id}')
 def reopen(id:str):
  b=service()
  with sqlite3.connect(b.path) as db:r=db.execute('SELECT forward FROM bridge_transfers WHERE id=?',(id,)).fetchone()
  if not r:raise ValueError('전송 기록이 없습니다.')
  f=json.loads(r[0]);f['issued_at']=int(time.time())
  return {'url':b.url()+'?delivery_id='+id+'#sunil_forward='+packed(f)}
 @app.post('/api/bridge/send')
 def send(req:Send):
  result,_=extraction(req)
  digest=hashlib.sha256(canonical(req.model_dump(exclude={'request_key'}))).hexdigest()
  return service().send(req.request_key,digest,result['rows'],req.reply_url)
 @app.post('/api/bridge/reply')
 def receive(req:Reply):return service().receive(req.envelope)
 @app.get('/api/bridge/result/{id}')
 def result(id:str):return service().result(id)
 @app.post('/api/bridge/set-notes')
 def notes(req:Notes):
  from .set_notes import apply_notes
  b=service()
  with sqlite3.connect(b.path) as db:
   db.execute('BEGIN IMMEDIATE');row=db.execute('SELECT snapshot,status FROM bridge_transfers WHERE id=?',(req.id,)).fetchone()
   if not row or row[1]=='confirmed':raise ValueError('이미 출고 확정됐거나 전송 자료가 없습니다.')
   records=json.loads(row[0]);apply_notes(records,req.notes)
   db.execute('UPDATE bridge_transfers SET snapshot=? WHERE id=?',(json.dumps(records,ensure_ascii=False),req.id))
  return b.result(req.id)
 @app.post('/api/bridge/confirm')
 def confirm(req:Confirm):return service().confirm(req.id)
